<p align="center" style="font-size: 28pt; font-weight: bold;">Thank you for your donation!</p>

Your donation will be redirected to the Associação de Ajuda Mútua do Pirambú - ACAMP (Pirambú Mutual Aid Community Association), in Fortaleza, Brazil.

ACAMP helps homeless children by providing them with shelter and food. Currently with the pandemic, the number of volunteers and donations has decreased and more than ever they need help.

On behalf of all the voluntiers, my family and the children helped by this project, I want to thank you for your donation.
