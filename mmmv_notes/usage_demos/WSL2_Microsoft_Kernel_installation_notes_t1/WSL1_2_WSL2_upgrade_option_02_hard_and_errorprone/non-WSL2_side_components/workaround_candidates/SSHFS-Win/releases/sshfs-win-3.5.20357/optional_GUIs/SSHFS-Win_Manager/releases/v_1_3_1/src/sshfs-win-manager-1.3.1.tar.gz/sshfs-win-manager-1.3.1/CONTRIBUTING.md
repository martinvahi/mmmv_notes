# Contributing to this project

This file is being written.

For informations on how to build this project, see issue #43
