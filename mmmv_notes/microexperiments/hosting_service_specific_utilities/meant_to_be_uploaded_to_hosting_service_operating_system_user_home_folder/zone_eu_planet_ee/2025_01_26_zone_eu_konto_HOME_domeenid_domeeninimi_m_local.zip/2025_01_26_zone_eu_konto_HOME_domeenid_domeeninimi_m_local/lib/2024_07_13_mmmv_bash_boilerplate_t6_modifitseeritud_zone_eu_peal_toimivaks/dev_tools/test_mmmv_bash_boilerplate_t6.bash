#!/usr/bin/env bash
#==========================================================================
# Initial author of this file: Martin.Vahi@softf1.com
# This file is in public domain.
#
# The following line is a spdx.org license label line:
# SPDX-License-Identifier: 0BSD
#==========================================================================
S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
S_FP_ORIG="`pwd`" # required by some tests
#S_TIMESTAMP="`date +%Y`_`date +%m`_`date +%d`_T_`date +%H`h_`date +%M`min_`date +%S`s"
#--------------------------------------------------------------------------
func_assert_error_code_zero(){
    local S_ERR_CODE="$1" # the "$?"
    local S_GUID_CANDIDATE="$2"
    #------------------------------
    if [ "$S_ERR_CODE" != "" ]; then
        # If the "$?" were evaluated in this function, 
        # then it would be "0" even, if it is
        # something else at the calling code.
        if [ "$S_ERR_CODE" != "0" ]; then
            echo ""
            echo -e "\e[31mTest failed. \e[39m"
            echo "    S_ERR_CODE==\"$S_ERR_CODE\""
            echo "GUID=='42e30c36-6c4e-4eb5-8e8b-134170a119e7'"
            echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
            echo ""
            #--------
            exit 1
        fi
    fi
    #------------------------------
} # func_assert_error_code_zero

#--------------------------------------------------------------------------
S_FP_MMMV_BASH_BOILERPLATE_TX_BASH="`cd $S_FP_DIR/../ ; pwd`/mmmv_bash_boilerplate_t6.bash"
#--------------------------------------------------------------------------
if [ ! -e "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH" ]; then
    func_assert_error_code_zero "42" '5a641ee3-0187-47d9-b48b-134170a119e7'
fi
if [ -d "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH" ]; then
    func_assert_error_code_zero "42" '3fa5e6b4-69e0-4e85-948b-134170a119e7'
fi
if [ -h "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH" ]; then
    func_assert_error_code_zero "42" '5e226093-7fe2-477c-9c8b-134170a119e7'
fi
source "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH"
func_assert_error_code_zero "$?" '2ccdedb5-8324-46cc-848b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_exc_determine_Awk_command_t1     # "" -> "t"
func_mmmv_exc_determine_Awk_command_t1 "t" # branch, because value not set
func_mmmv_exc_determine_Awk_command_t1 "f" # branch, because value set but forced to recalc
func_mmmv_exc_determine_Awk_command_t1 "t" # branch, because value set and reuse requested
#--------
func_mmmv_exc_determine_sed_command_t1     # "" -> "t"
func_mmmv_exc_determine_sed_command_t1 "t" # branch, because value not set
func_mmmv_exc_determine_sed_command_t1 "f" # branch, because value set but forced to recalc
func_mmmv_exc_determine_sed_command_t1 "t" # branch, because value set and reuse requested
#--------------------------------------------------------------------------
if [ -e "/usr" ]; then # exists, because the 
    # Android specific Linux distrubution named Termux 
    # is an application at Android userspace and 
    # at least at some Android versions the "/usr" 
    # is not always even readable from the Android userspace.
    if [ -d "/usr" ]; then
        func_mmmv_add_bin_2_Z_PATH_and_optionally_share_man_2_MANPATH_t1 \
            "/usr" \
            '11fc3642-bdc8-4302-a38b-134170a119e7'
    else
        echo ""
        echo -e "The \"\e[31m/usr\e[39m\" exists, but it is not a folder. "
        echo "GUID=='28c72b5e-fd27-444e-b38b-134170a119e7'"
        echo ""
    fi
fi
#--------------------------------------------------------------------------
func_mmmv_assert_Linux_or_BSD_t1 \
    '2a437d3c-9549-401b-a38b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_assert_error_code_zero_t1 "0" \
    '71615ea0-8a36-4688-818b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_assert_error_code_zero_t2 "0" \
    '151d7883-ede4-439b-8c8b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_assert_error_code_zero_t3 "0" \
    '9c1b0357-05c1-4e12-b18b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_assert_error_code_zero_t4 "0" \
    '216171a4-c33f-4f5b-948b-134170a119e7'
#--------------------------------------------------------------------------
S_TMP_000="Foo"
func_mmmv_assert_nonempty_string_but_do_not_exit_t1 \
    "$S_TMP_000" "S_TMP_000" \
    'c8501244-fa50-43f7-928b-134170a119e7'
func_mmmv_assert_nonempty_string_t1 \
    "$S_TMP_000" "S_TMP_000" \
    'c44be23e-8f74-4b2c-a38b-134170a119e7'
SB_NO_ERRORS_YET="t"
S_TMP_000=" "
func_mmmv_assert_nonempty_string_but_do_not_exit_t1 \
    "$S_TMP_000" "S_TMP_000" \
    '5e91785f-a659-4d5e-838b-134170a119e7'
func_mmmv_assert_nonempty_string_t1 \
    "$S_TMP_000" "S_TMP_000" \
    '2f407ce3-3438-4d32-838b-134170a119e7'
# #--start-of-tests-that-are-expected-to-fail--
# SB_NO_ERRORS_YET="f"
# S_TMP_000="Bar"
# func_mmmv_assert_nonempty_string_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     '25182124-a83b-4ae8-a58b-134170a119e7'
# S_TMP_000=""
# func_mmmv_assert_nonempty_string_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     '4d1f213a-5707-4401-a48b-134170a119e7'
#--------------------------------------------------------------------------
SB_NO_ERRORS_YET="t"
S_TMP_000="t"
func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
    "$S_TMP_000" "S_TMP_000" \
    '2cf82227-ecdf-481b-a28b-134170a119e7'
func_mmmv_assert_sbvar_domain_t_f_t1 \
    "$S_TMP_000" "S_TMP_000" \
    '19547235-1d08-4000-a38b-134170a119e7'
S_TMP_000="f"
func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
    "$S_TMP_000" "S_TMP_000" \
    '365a94ac-43fc-48f2-858b-134170a119e7'
func_mmmv_assert_sbvar_domain_t_f_t1 \
    "$S_TMP_000" "S_TMP_000" \
    'd45ff02e-7dd6-4a37-a58b-134170a119e7'
# #--start-of-tests-that-are-expected-to-fail--
# SB_NO_ERRORS_YET="f"
# S_TMP_000="t"
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     'abf0ae43-43e8-4e60-b38b-134170a119e7'
# SB_NO_ERRORS_YET="f"
# S_TMP_000="f"
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     'dc7807b3-98b9-4280-b57b-134170a119e7'
# SB_NO_ERRORS_YET="t"
# S_TMP_000="f"
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     'd12f2447-9cfc-45a6-857b-134170a119e7'
# SB_NO_ERRORS_YET="t"
# S_TMP_000=""
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     '5cd6d9f4-9db8-47e4-817b-134170a119e7'
# SB_NO_ERRORS_YET="t"
# S_TMP_000=" "
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     '8484585f-c86b-42db-947b-134170a119e7'
# SB_NO_ERRORS_YET="t"
# S_TMP_000="X"
# func_mmmv_assert_sbvar_domain_t_f_but_do_not_exit_t1 \
#     "$S_TMP_000" "S_TMP_000" \
#     '18ff9a85-3c70-45ee-a17b-134170a119e7'
#--------------------------------------------------------------------------
# func_mmmv_cd_S_FP_ORIG_and_exit_t1
#--------------------------------------------------------------------------
# func_mmmv_create_folder_t1
#--------------------------------------------------------------------------
# func_mmmv_exc_exit_with_an_error_t1
#--------------------------------------------------------------------------
# func_mmmv_exc_exit_with_an_error_t2
#--------------------------------------------------------------------------
# func_mmmv_exit_t1
#--------------------------------------------------------------------------
func_mmmv_include_bashfile_if_possible_t1 \
    "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH" \
    '84c9ff6f-a4bb-4ced-817b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_include_bashfile_if_possible_t2 \
    "$S_FP_MMMV_BASH_BOILERPLATE_TX_BASH" \
    '8b50845c-0cb4-48ad-847b-134170a119e7'
#--------------------------------------------------------------------------
func_mmmv_init_s_timestamp_if_not_inited_t1
#--------------------------------------------------------------------------
# func_mmmv_report_an_error_but_do_not_exit_t1
#--------------------------------------------------------------------------
func_mmmv_verify_S_FP_ORIG_but_do_not_exit_t1
func_mmmv_exc_verify_S_FP_ORIG_t1
func_mmmv_exc_verify_S_FP_ORIG_t2
#--------------------------------------------------------------------------
func_mmmv_operatingsystem_is_Linux "SB_TMP_0"
func_mmmv_operatingsystem_is_BSD "SB_TMP_0"
func_mmmv_operatingsystem_is_macOS "SB_TMP_0"
# blkid ei ole zone.eu serveris 2025_01_26 seisuga tavakasutajatele k2ttesaadav
# if [ "`uname -a 2> /dev/null | grep -E '(Linux|BSD)' `" != "" ]; then
#     func_mmmv_assert_Linux_or_BSD_t1 '38268d4e-63ef-4777-a27b-134170a119e7'
#     #----------------------------------------
#     S_FP_0="/dev/sda1" # probably always present
#     # blkid | grep '/dev/sda1' | sed -e 's/^[^U]\+UUID[=]["]//g' | sed -e 's/["].\+$//g'
#     S_UUID="`blkid | grep '/dev/sda1' | sed -e 's/^[^U]\\+UUID[=][\"]//g' | sed -e 's/[\"].\\+\$//g'`"
#     #-------
#     S_BLOCK_DEVICE_ID_SUBPART_CANDIDATE="$S_UUID"
#     func_mmmv_exc_block_device_ID_to_device_file_name_t1 \
#         "$S_BLOCK_DEVICE_ID_SUBPART_CANDIDATE" \
#         "70720f31-2bf1-4799-938b-134170a119e7"
#     if [ "$S_FP_DEVICE_FILE" != "$S_FP_0" ]; then
#         func_mmmv_exc_exit_with_an_error_t2 \
#             "6eccb018-62dd-4a62-918b-134170a119e7"
#     fi
#     #----------------------------------------
# fi
#--------------------------------------------------------------------------
S_MMMV_OPERATING_SYSTEM="FooBar_operating_system"
func_mmmv_determine_operatingsystem_t1     # "" -> "t"
func_mmmv_determine_operatingsystem_t1 "t" # branch, because value not set
func_mmmv_determine_operatingsystem_t1 "f" # branch, because value set but forced to recalc
func_mmmv_determine_operatingsystem_t1 "t" # branch, because value set and reuse requested
#echo "Operating system name is: $S_MMMV_OPERATING_SYSTEM"
#--------------------------------------------------------------------------
SB_RESULT="to_be_set"
func_mmmv_sb_s_on_PATH_t1 "this_does_not_possibly_exist_4440o0" \
    "bac48922-1c09-47f8-828b-134170a119e7"
if [ "$SB_RESULT" != "f" ]; then
    func_mmmv_exc_exit_with_an_error_t2 \
        "58e54ae7-30d4-4192-a18b-134170a119e7"
fi
func_mmmv_sb_s_on_PATH_t1 "ls" \
    "321c4d3c-8f0c-44ec-a18b-134170a119e7"
if [ "$SB_RESULT" != "t" ]; then
    func_mmmv_exc_exit_with_an_error_t2 \
        "20b5391f-7d64-4fa8-838b-134170a119e7"
fi
#--------------------------------------------------------------------------
S_EXPECTED_SUBSTRING="`hostname`"
func_mmmv_assert_uname_hyphen_a_output_includes_t1 "$S_EXPECTED_SUBSTRING" \
    "290b62a2-6c32-47d2-a18b-134170a119e7"
#--------------------------------------------------------------------------
S_EXPECTED_USER_NAME="`whoami`"
func_mmmv_assert_current_user_t1 "$S_EXPECTED_USER_NAME" \
    "4e2b0e49-cd48-490b-838b-134170a119e7"
#--------------------------------------------------------------------------
S_GENERATED_GUID=""  # "26f55048-ae44-4c38-858b-134170a119e7"
func_mmmv_s_generate_GUID_t1 
if [ "$S_GENERATED_GUID" == "" ]; then
    func_mmmv_exc_exit_with_an_error_t2 \
        "22b34775-cf88-414a-a18b-134170a119e7"
fi
#--------------------------------------------------------------------------
func_mmmv_wait_and_sync_t1
echo ""
echo -e "\e[32mSuperficial tests passed without detecting any errors. \e[39m"
echo ""
exit 0 # no errors detected
#==========================================================================
# S_VERSION_OF_THIS_FILE="9bd54a2e-5145-416b-818b-134170a119e7"
#==========================================================================
