#!/usr/bin/env bash
#==========================================================================
# Author of this file: Martin.Vahi@softf1.com
# This file is in public domain.
# The following line is a spdx.org license label line:
# SPDX-License-Identifier: 0BSD
#
# Some references:
#     https://www.qemu.org/docs/master/system/qemu-manpage.html
#
# The Control flow entry is the func_main() at the end of this file.
#==========================================================================
S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
func_settings(){
    #----------------------------------------------------------------------
    # The ISO file that is referenced by the
    S_FP_DVD_ISO="$S_FP_DIR/live_CD/HelenOS/HelenOS-0.14.1-sparc64-ultra.iso"
    # has been downloaded on 2026_10_06 from
    # http://www.helenos.org/releases/HelenOS-0.14.1-sparc64-ultra.iso
    # and it is the "Sun Ultra 5/60" variety. The page that helped to
    # find the SPARC specific binary: https://archiveos.org/helenos/

    S_QEMU_SYSTEM="qemu-system-sparc64"
    SI_N_OF_EMULATED_CPUCORES="1"
    #----------------------------------------------------------------------
    # An empty value for the
    S_QEMU_KEYBOARD_AND_MOUSE_GRABBING_PARAMETER=""
    # is not advised, because it defaults to
    # Ctrl-Alt-g, which collides
    # with X2Go keyboard and mouse grabbing keyboard shortcut
    # and possibly with keyboard shortcuts of other programs.

    # left-Ctrl +left-Alt + left-Shiuft + g
    #S_QEMU_KEYBOARD_AND_MOUSE_GRABBING_PARAMETER=",grab-mod=lshift-lctrl-lalt"

    # right-Ctrl + g
    S_QEMU_KEYBOARD_AND_MOUSE_GRABBING_PARAMETER=",grab-mod=rctrl"  # right Ctrl-g
    #----------------------------------------------------------------------
    # A command for creating a QEMU appliance compressed HDD image:
    #     qemu-img create -f qcow2 /a/full/path/to/an_HDD.img  30G
    S_FP_HDD="$S_FP_DIR/HDDimages/foo_HDD.img"
    #----------------------------------------------------------------------
} # func_settings
#==========================================================================
func_mmmv_assert_exists_on_path_t1g() {
    local S_NAME_OF_THE_EXECUTABLE="$1" # first function argument
    #----------------------------------------------------------------------
    local S_TMP_0="\`which $S_NAME_OF_THE_EXECUTABLE 2> /dev/null\`"
    local S_TMP_1=""
    local S_TMP_2="S_TMP_1=$S_TMP_0"
    eval ${S_TMP_2}
    if [ "$S_TMP_1" == "" ]; then
        S_TMP_0="This bash script requires the \""
        S_TMP_1="\" to be on the PATH."
        #--------
        echo ""
        echo -e "$S_TMP_0\e[31m$S_NAME_OF_THE_EXECUTABLE\e[39m$S_TMP_1"
        echo "GUID=='4e55e822-ae7b-41f2-a131-31d27060aae7'"
        echo ""
        exit 1 # exit with an error
    fi
} # func_mmmv_assert_exists_on_path_t1g

func_mmmv_assert_error_code_zero_t1g(){
    local S_ERR_CODE="$1" # the "$?"
    local S_GUID_CANDIDATE="$2"
    #----------------------------------------------------------------------
    if [ "$S_GUID_CANDIDATE" == "" ]; then
        echo ""
        echo -e "\e[31mThe Bash code that calls this function is flawed. \e[39m"
        echo ""
        echo "    S_GUID_CANDIDATE==\"\""
        echo ""
        echo "but it is expected to be a GUID."
        echo "Aborting script."
        echo "GUID=='10058b94-4083-427f-8831-31d27060aae7'"
        echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        echo ""
        exit 1
    fi
    #------------------------------
    # If the "$?" were evaluated in this function,
    # then it would be "0" even, if it is
    # something else at the calling code.
    if [ "$S_ERR_CODE" != "0" ];then
        echo ""
        echo "Something went wrong. Error code: $S_ERR_CODE"
        echo -e "\e[31mAborting script. \e[39m"
        echo "GUID=='d50f535a-1004-4ebe-a331-31d27060aae7'"
        echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        echo ""
        exit 1
    fi
    #------------------------------
} # func_mmmv_assert_error_code_zero_t1g
#--------------------------------------------------------------------------

func_main(){
    #----------------------------------------------------------------------
    func_settings
    func_mmmv_assert_exists_on_path_t1g "nice"
    func_mmmv_assert_exists_on_path_t1g "$S_QEMU_SYSTEM"
    #----------------------------------------------------------------------
    nice -n 5 $S_QEMU_SYSTEM -M sun4u -m 1G -boot d \
         -cdrom $S_FP_DVD_ISO \
         -display sdl,show-cursor=on,gl=off$S_QEMU_KEYBOARD_AND_MOUSE_GRABBING_PARAMETER \
         -drive cache=writeback,file=$S_FP_HDD \
         -icount shift=1,align=off \
         -monitor stdio \
         -net nic \
         -net user,hostfwd=tcp:127.0.0.1:2222-:22 \
         -smp $SI_N_OF_EMULATED_CPUCORES
        #-------------------------
        # -accel tcg,thread=multi  
                                   # Supposedly that allows host machine to 
                                   # use more than 1 CPU-core even if
                                   # the virtual appliance is a 
                                   # single core computer.
    #----------------------------------------------------------------------
    func_mmmv_assert_error_code_zero_t1g "$?" \
        "862e0dc1-d4bd-4352-bb31-31d27060aae7"
    #----------------------------------------------------------------------
} # func_main
func_main

#==========================================================================
# S_VERSION_OF_THIS_FILE="e0856b1f-33a7-4744-b431-31d27060aae7"
#==========================================================================
